# Penalty Shoot World Cup - Android prototype

Mobile-first HTML5 game with original pixel-art adult athlete sprite sheets and animated striker/goalkeeper frames.

## Quick play on Android
1. Extract the ZIP.
2. Upload the `www` folder to a static HTTPS host (GitHub Pages / Netlify), or open `index.html` in a browser for local preview.
3. For an installable PWA, open the HTTPS URL in Chrome Android and choose **Install app** / **Add to Home Screen**.

## Build a native APK
This package includes a Capacitor project configuration, but this environment does not have Android SDK, Gradle, or Android build-tools installed. Therefore I cannot truthfully provide a compiled/signed APK from here.

On a computer with Node.js and Android Studio installed:
1. Extract the ZIP and open a terminal in the project folder.
2. Run `npm install`.
3. Run `npx cap add android`.
4. Run `npx cap sync android`.
5. Run `npx cap open android`.
6. In Android Studio, build the APK using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. For distribution, create a signed APK via **Build > Generate Signed Bundle / APK**.

## Game
- Select a country and goalkeeper difficulty.
- Pick one of 9 goal zones.
- Choose Placed, Power, or Chip and adjust power.
- The goalkeeper predicts the target; matching prediction is a save, otherwise a goal.
- Practice and World Cup-style tournament modes are included.

## Notes
This is a playable prototype, not a finished commercial game. Tournament progression and match rules can be expanded in the next iteration. AI uses simple shot-history heuristics. The 1/9 chance applies to uniformly random guesses; harder AI deliberately adapts to repeated player patterns.
